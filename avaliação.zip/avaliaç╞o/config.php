<?php
    define('HOST', 'localhost');
    define('USER', 'root');
    define('PASS', '');
    define('BASE', 'vestibular');

    $conn = new MySQLi(HOST, USER, PASS, BASE);


?>